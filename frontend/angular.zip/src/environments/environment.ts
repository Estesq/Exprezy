// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyBNa385vCj0V4MLq5w_-DbrqUVstVmVm4k",
    authDomain: "exprezy-18e3e.firebaseapp.com",
    databaseURL: "https://exprezy-18e3e.firebaseio.com",
    projectId: "exprezy-18e3e",
    storageBucket: "exprezy-18e3e.appspot.com",
    messagingSenderId: "379447121042",
    appId: "1:379447121042:web:fb3078a14ce46e056b424b",
    measurementId: "G-LRX7M9WN4V"
  },
  
serverlink : "http://localhost:5000" 
};
// serverlink : "https://exprezy-18e3e.web.app" 
// serverlink : "http://localhost:5000" 